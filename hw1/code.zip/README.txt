Name: Matthew Wu
ID: 26604548

Instructions:

All programs can be run using Python 3 from terminal after making the appropriate edits to the appropriate files as described below.

1) To reproduce the MNIST results, first open the classify_numbers.py file, and uncomment the functions of interest. To generate the plot for problem 2, uncomment generate_plot. To generate the plot for problem 3, uncomment find_c_value. To generate the csv file submitted to Kaggle, uncomment predict_test_set

2) To reproduce the Spam results, first run featurize.py as I added different feature vectors to it. Aside from that, follow the steps as described in part 1.

3) Since there is only one plot for classifying the images, it can be run as is.