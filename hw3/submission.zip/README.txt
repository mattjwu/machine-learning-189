Name: Matthew Wu
ID: 26604548

Instructions:

All programs can be run using Python 3 from terminal after making the appropriate edits to the appropriate files as described below.

1) To reproduce the MNIST results, first open the classify_numbers.py file, and uncomment the functions of interest.

2) To reproduce the Spam results, first run featurize.py, then run the file.

3) Isocontours and Covariance can be run as is.